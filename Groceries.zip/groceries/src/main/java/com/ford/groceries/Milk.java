package com.ford.groceries;

public class Milk implements Product{
	public double cost(int unit) {
		// TODO Auto-generated method stub
		return unit*1.30;
	}
}
