package com.ford.groceries;


public class Soup implements Product{

	public double cost(int unit) {
		return unit*0.65;
	}
}
