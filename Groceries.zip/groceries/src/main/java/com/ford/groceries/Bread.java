package com.ford.groceries;

public class Bread implements Product{
	
	public double cost(int unit) {
		// TODO Auto-generated method stub
		return unit*0.8;
	}

}
