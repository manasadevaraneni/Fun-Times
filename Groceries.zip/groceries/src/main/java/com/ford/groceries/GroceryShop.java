
// Thirdware Programming Challenge
// Manasa D
package com.ford.groceries;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

/**
 * Hello world!
 *
 */
public class GroceryShop 
{
	public  Product getPrice(String productType){
		if(productType == null)
			return null;
		else if(productType.equalsIgnoreCase("soup"))
			return new Soup();
		else if(productType.equalsIgnoreCase("bread"))
			return new Bread();
		else if(productType.equalsIgnoreCase("milk"))
			return new Milk();
		if(productType.equalsIgnoreCase("apples"))
			return new Apples();
		return null;
	}
	
	public static void main(String[] args) {
		//Instead of reading from commandprompt here, I have taken inputs manually Due to time constraints
		Map<String,Integer> input = new TreeMap<String,Integer>(String.CASE_INSENSITIVE_ORDER); // to make map key case insensitive
		input.put("soup", 2); // products and quantity
		input.put("bread", 1); 
		input.put("apples", 3);
	//	input.put("milk", 1);
		input.put("time",5);
		
		double totalPrice = 0.0;
		double add = 0;
		int days = input.get("time");
		
		GroceryShop shop = new GroceryShop();
		for(Map.Entry<String, Integer> map: input.entrySet()){
			if( !map.getKey().equals("time") ){ //Skip the loop if we encountered "time" in map
				
				if( map.getKey().equals("apples") && !offerAppliedOnApples(days)) //if the time of buy is not eligible for discount on apples
					totalPrice = totalPrice+ input.get("apples")*0.1;
				else //calculating prices according to the productnames
					totalPrice = totalPrice+(shop.getPrice(map.getKey()).cost(map.getValue()) );
				}
			
		}
		// Writing loop for discount on soup
		if(input.containsKey("soup") && input.get("soup")>=2 && input.containsKey("bread") && isOfferApplicableOnSoup(days)){
			add = 0.80 * (input.get("soup")/2)/2.0;
		}
		System.out.println("Expected total cost = "+(float)(totalPrice - add));
	}
	public static boolean isOfferApplicableOnSoup(int day){
		//Boolean to check the discount on soup- eligibility based on the time of buy
		if(TimeFactory.getNthDay(day).equals(TimeFactory.today) ||( TimeFactory.getNthDay(day).after(TimeFactory.today) && TimeFactory.getNthDay(day).before(TimeFactory.getNthDay(8))))
			return true;
		return false;
	}
	// Boolen function to check the eligability on apple discount
	public static  boolean offerAppliedOnApples(int day){
		Date thirdDay = TimeFactory.getMthDay(3);
		Date given = TimeFactory.getNthDay(day);
		Date month = TimeFactory.getLastDateOfMonth();
//		System.out.println(thirdDay+"  "+given+" "+month);
		if(given.after(thirdDay) && given.before(month))
			return true;
		return false;
	}
}