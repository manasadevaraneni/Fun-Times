package com.ford.groceries;

public class Apples implements Product{
	
	public double cost(int unit) {
		return unit*0.10*0.9;
	}

}
