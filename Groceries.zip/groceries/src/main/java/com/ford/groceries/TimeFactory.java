package com.ford.groceries;

import java.util.Calendar;
import java.util.Date;

public class TimeFactory {
	static Date today = new Date(); 
	public static Date getNthDay(int days){
	 
		Calendar yCalendar = Calendar.getInstance();
		yCalendar.setTime(today);
		yCalendar.add(Calendar.DATE, days);
		return yCalendar.getTime();
	}
	
	public static Date getMthDay(int days){
		 
		Calendar yCalendar = Calendar.getInstance();
		yCalendar.setTime(today);
		yCalendar.add(Calendar.DATE, days);
		return yCalendar.getTime();
	}
	
	public static Date getLastDateOfMonth(){

		Calendar calendar = Calendar.getInstance();  
		calendar.setTime(today);  

		calendar.add(Calendar.MONTH, 2);  
		calendar.set(Calendar.DAY_OF_MONTH, 1);  
		calendar.add(Calendar.DATE, -1); 
		return calendar.getTime();
	}

}
