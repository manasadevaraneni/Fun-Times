package com.ford.groceries;


public interface Product {
	abstract double cost(int unit);
}
